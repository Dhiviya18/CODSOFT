import java.util.Scanner;

public class Numbergame 
{
	public static void main(String[] args) 
	{
        Scanner sc=new Scanner(System.in);
        int chances=6;
        int finals=0;
        boolean playAgain=true;
        System.out.println("Welcome to play Number Game");
        System.out.println("Hello Player you have about"+" "+chances+" "+"to win the game");
        while(playAgain)
        {
        	int rand=getrandN(1,100);
        	boolean guess=false;
        	for(int i=0;i<chances;i++)
        	{
        		System.out.println("Chances"+":"+(i+1));
        		System.out.println("Enter your guess:");
        		int user=sc.nextInt();
        		if(user==rand)
        		{
        			guess=true;
        			finals+=1;
        			System.out.println("You Succeeded ");
        			break;
        		}
        		else if(user>rand)
        		{
        			System.out.println("Your Guess is too High");
        		}
        		else
        		{
        			System.out.println("Your Guess is too Low");
        		}
        	}
        	if(!guess)
        	{
        		System.out.println("Sorry!You have lost your chances.");
        		System.out.println("The number was "+rand);
        	}
        	System.out.println("Are you ready to play again(yes/no)");
        	String plyagn=sc.next();
        	playAgain=plyagn.equalsIgnoreCase("yes");
        	
        }
        System.out.println("That's it Buddy");
        System.out.println("Hope You enjoyed it");
        System.out.println("Here is your score:"+" "+finals);
	}
	public static int getrandN(int min,int max)
        {
        	return(int)(Math.random()*(max-min+1)+min);
        }
        
}
