import java.util.*;
class Course 
{
    String code;
    String title;
    String description;
    int capacity;
    String schedule;
    ArrayList<Student> enrolledStudents;

    public Course(String code, String title, String description, int capacity, String schedule) 
    {
        this.code = code;
        this.title = title;
        this.description = description;
        this.capacity = capacity;
        this.schedule = schedule;
        this.enrolledStudents = new ArrayList<>();
    }

    public boolean hasAvailableSlot() 
    {
        return enrolledStudents.size() < capacity;
    }

    public void registerStudent(Student student) 
    {
        if (hasAvailableSlot()) 
        {
            enrolledStudents.add(student);
            student.registeredCourses.add(this);
            System.out.println(student.name + " successfully registered for " + title);
        } 
        else 
        {
            System.out.println("Course " + title + " is full!");
        }
    }

    public void removeStudent(Student student) 
    {
        if (enrolledStudents.remove(student)) 
        {
            student.registeredCourses.remove(this);
            System.out.println(student.name + " successfully removed from " + title);
        } 
        else 
        {
            System.out.println(student.name + " is not registered for " + title);
        }
    }

    public void displayCourseInfo() 
    {
        System.out.println("Course Code: " + code);
        System.out.println("Title: " + title);
        System.out.println("Description: " + description);
        System.out.println("Schedule: " + schedule);
        System.out.println("Capacity: " + capacity + ", Available Slots: " + (capacity - enrolledStudents.size()));
        System.out.println();
    }
}

class Student 
{
    String id;
    String name;
    ArrayList<Course> registeredCourses;

    public Student(String id, String name) 
    {
        this.id = id;
        this.name = name;
        this.registeredCourses = new ArrayList<>();
    }

    public void displayRegisteredCourses()
    {
        System.out.println(name + " is registered for the following courses:");
        for (Course course : registeredCourses) 
        {
            System.out.println("- " + course.title);
        }
        System.out.println();
    }
}

public class Main
{
    static ArrayList<Course> courses = new ArrayList<>();
    static ArrayList<Student> students = new ArrayList<>();

    public static void main(String[] args) 
    {
        Scanner scanner = new Scanner(System.in);
        courses.add(new Course("CS101", "Introduction to Computer Science", "Basic concepts of computer science.", 30, "Mon & Wed 10:00-11:30"));
        courses.add(new Course("MATH201", "Mathematics I", "Differential and integral calculus.", 40, "Tue & Thu 09:00-10:30"));
        courses.add(new Course("ENG301", "English Literature", "Study of English literary works.", 25, "Fri 13:00-14:30"));

    
        students.add(new Student("ITR018", "Alice Johnson"));
        students.add(new Student("ITR032", "Bob Smith"));

        int choice;
        do 
        {
            System.out.println("***STUDENT COURSE REGISTRATION SYSTEM***");
            System.out.println("WELCOME STUDENTS!!!");
            System.out.println("1. List available courses");
            System.out.println("2. Register for a course");
            System.out.println("3. Drop a course");
            System.out.println("4. Display registered courses");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            switch (choice) 
            {
                case 1:
                    listAvailableCourses();
                    break;
                case 2:
                    registerCourse(scanner);
                    break;
                case 3:
                    dropCourse(scanner);
                    break;
                case 4:
                    displayRegisteredCourses(scanner);
                    break;
                case 5:
                    System.out.println("Exiting the system.");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 5);
    }

    private static void listAvailableCourses() 
    {
        System.out.println("Available Courses:");
        for (Course course : courses) 
        {
            course.displayCourseInfo();
        }
    }

    private static void registerCourse(Scanner scanner) 
    {
        System.out.print("Enter your student ID: ");
        String studentId = scanner.next();
        Student student = findStudentById(studentId);
        if (student == null) 
        {
            System.out.println("Student not found.");
            return;
        }

        System.out.print("Enter the course code to register: ");
        String courseCode = scanner.next();
        Course course = findCourseByCode(courseCode);
        if (course == null) 
        {
            System.out.println("Course not found.");
            return;
        }

        course.registerStudent(student);
    }

    private static void dropCourse(Scanner scanner) 
    {
        System.out.print("Enter your student ID: ");
        String studentId = scanner.next();
        Student student = findStudentById(studentId);
        if (student == null) 
        {
            System.out.println("Student not found.");
            return;
        }

        System.out.print("Enter the course code to drop: ");
        String courseCode = scanner.next();
        Course course = findCourseByCode(courseCode);
        if (course == null) 
        {
            System.out.println("Course not found.");
            return;
        }

        course.removeStudent(student);
    }

    private static void displayRegisteredCourses(Scanner scanner) 
    {
        System.out.print("Enter your student ID: ");
        String studentId = scanner.next();
        Student student = findStudentById(studentId);
        if (student == null) 
        {
            System.out.println("Student not found.");
            return;
        }

        student.displayRegisteredCourses();
    }

    private static Student findStudentById(String id) 
    {
        for (Student student : students) 
        {
            if (student.id.equals(id)) 
            {
                return student;
            }
        }
        return null;
    }

    private static Course findCourseByCode(String code) 
    {
        for (Course course : courses)
        {
            if (course.code.equals(code)) 
            {
                return course;
            }
        }
        return null;
    }
}
